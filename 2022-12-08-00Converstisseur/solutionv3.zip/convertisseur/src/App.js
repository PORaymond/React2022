import { Component } from 'react';
import { Container, Message } from 'semantic-ui-react';
import './App.css';
import Recherche from './Components/Recherche';

class App extends Component {

  state = {
    data: '',
    error: ''
  }

  onAffichage = (a, b) => {
    console.log("ahahah");
    return (<div style={{backgroundColor:"red"}}>
      {this.state.data [a] ? <Message>  {this.state.data[a][b]} </Message>:undefined}
      {this.state.error? <Message>{this.state.error}</Message>:undefined} 
    </div>);
  }

  onAppelApi = async (a, b) => {
    if (a && b) {
      try {
        let response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${a}&vs_currencies=${b}`);
        let donnees = await response.json();
        this.setState({
          data: donnees,
          error: ''
        })
        console.log(this.state.data);
      }
      catch (e) {
        this.setState({ error: 'APPEL API échoué' })
      }
    }
    else {
      this.setState({ error: ' il faut choisir la source et la destination' })
    }
  }

  render() {
    return (
      <Container>
        <Recherche api={this.onAppelApi} aff={this.onAffichage} />

      </Container>
    );
  }

}

export default App;
