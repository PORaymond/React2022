import React, { Component } from 'react';
import { Button, Container, Message, Select } from 'semantic-ui-react';
import '../Recherche.css';

class Recherche extends Component {

    state = {
        source: '',
        destination: ''
        
    }

    

    onSourceChange = (e, data) => {
        this.setState({
            source: data.value
        });
    }
    
    onDestinationChange = (e, data) => {
        this.setState({
            destination: data.value
        })
    }

    
    


    onVider = () => {
        this.setState({
            source: '',
            destination: ''
        });
    }


    render() {
        
        console.log(this.state.source, this.state.destination);
        const optionsSource = [
            { key: 'af', value: 'bitcoin', text: 'Bitcoin' },
            { key: 'ax', value: 'ethereum', text: 'Ethereum' },
            { key: 'al', value: 'cardano', text: 'Cardano' },
        ]
        const optionsDestination = [
            { key: 'af', value: 'cad', text: 'Dollard Canadien' },
            { key: 'ax', value: 'usd', text: 'Dollard Americain' },
            { key: 'al', value: 'eur', text: 'Euro' },

        ]

        return (
            <Container >
                <h1>Conversion de crypto monnaie</h1>
                <div className="recherche">
                    <Select onChange={this.onSourceChange} placeholder="Choisissez le crypto" options={optionsSource} />
                    <Select onChange={this.onDestinationChange} placeholder="Choisissez la destination" options={optionsDestination} />
                    <Button onClick={()=>{this.props.api(this.state.source,this.state.destination)}} primary> Convertir </Button>
                    <Button onClick={this.onVider} secondary> Vider</Button>
                    {this.props.aff(this.state.source,this.state.destination)}
                </div>
               
                 
    
            </Container>
        );
    }
}

export default Recherche;