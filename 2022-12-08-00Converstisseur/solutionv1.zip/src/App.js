import { Container } from 'semantic-ui-react';
import './App.css';
import Recherche from './Components/Recherche';

function App() {
  return (
    <Container>
      <Recherche />
    </Container>
  );
}

export default App;
