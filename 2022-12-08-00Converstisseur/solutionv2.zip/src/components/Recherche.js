import reactDom, { Component } from 'react';
import React from 'react';
import { Button, Select } from 'semantic-ui-react';

class Recherche extends Component {
    state = {
        crypto: this.props.crypto,
        monnaie: this.props.monnaie
    }

    onCryptoChange = (e, data) => {
        this.setState({crypto: data.value})
    }

    onMonnaieChange = (e, data) => {
        this.setState({ monnaie: data.value })
    }

    render() {
        const optionsCrypto = [
            { value: "bitcoin", key: "bitcoin", text: "Bitcoin" },
            { value: "ethereum", key: "ethereum", text: "Ethereum" },
            { value: "cardano", key: "cardano", text: "Cardano" }
        ];
        const optionsMonnaie = [
            { value: "cad", key: "cad", text: "Dollar Canadien" },
            { value: "usd", key: "usd", text: "Dollar Americain" },
            { value: "eur", key: "eur", text: "Euro" }
        ]
        return (
            <div className="recherche">
                <h1>Conversion de crypto monnaie</h1>
                <Select onChange={this.onCryptoChange} placeholder="Choisizes le crypto" options={optionsCrypto} value={this.state.crypto} />
                <Select onChange={this.onMonnaieChange} placeholder="Choisizes la monnaie" options={optionsMonnaie} value={this.state.monnaie} />
                <Button onClick={()=>this.props.onSearch(this.state.crypto, this.state.monnaie) }primary>Convertir</Button>
                <Button onClick={() => this.props.onEmpty()} secondary>Vider la recherche</Button>
            </div >
        )
    }
}

export default Recherche;